/** Initialize neccessary modules */
const helpers = require("../services/helpers/Helpers");

/** Exports the functions of Helper */
module.exports = {
  CapitalizeFirstLetter: helpers.CapitalizeFirstLetter,
};